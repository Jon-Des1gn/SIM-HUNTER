# SIM HUNTER

A collectible phone-number game for Android.

## Concept
Generate virtual phone numbers, discover rare combinations, build a collection and unlock new number categories.

### Categories
- Russia +7
- USA +1
- United Kingdom +44
- Japan +81
- Germany +49
- Canada +1
- Anonymous +888 (fictional in-game category)

> All numbers in the game are virtual/game content and are not real assignable SIM cards.

## Prototype
The first build focuses on the core loop:
1. Choose an unlocked category.
2. Generate a random virtual number.
3. Analyze its digit pattern.
4. Assign rarity.
5. Add it to the collection.
6. Track progress and currency.

## Tech
- Kotlin
- Jetpack Compose
- Material 3
- Android 8.0+ (API 26+)

## Project name
**SIM HUNTER**

Possible future branding:
**SIM HUNTER — Собирай. Охоться. Находи редкие номера.**