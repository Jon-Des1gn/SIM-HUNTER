package com.jon.simhunter

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhonelinkRing
import androidx.compose.material.icons.filled.Sell
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.graphicsLayer
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

private const val GENERATION_COST = 50L
private const val VERSION = "0.2.0"

private val DarkBackground = Color(0xFF05070A)
private val DarkSurface = Color(0xFF0A1017)
private val DarkSurface2 = Color(0xFF101820)
private val TextMain = Color(0xFFF2F5F8)
private val TextMuted = Color(0xFF8D98A6)
private val Accent = Color(0xFF75C9FF)
private val AccentPurple = Color(0xFF9A80FF)

private data class Country(
    val nameRu: String,
    val nameEn: String,
    val flag: String,
    val code: String,
    val baseChance: Double,
    val unlockAt: Int
) {
    val key: String get() = "$nameRu|$code"
}

private data class PoolNumber(
    val localDigits: String,
    val beautiful: Boolean,
    val rarity: String,
    val stars: Int,
    val pattern: String,
    val estimatedValue: Long
)

private data class PhoneNumber(
    val country: Country,
    val localDigits: String,
    val rarity: String,
    val stars: Int,
    val pattern: String,
    val estimatedValue: Long
) {
    val id: String get() = "${country.key}:$localDigits"
    val saleCoins: Long get() = max(GENERATION_COST, estimatedValue / 100L)
}

private data class GameSnapshot(
    val coins: Long = 1250L,
    val collection: List<PhoneNumber> = emptyList(),
    val generatedCount: Int = 0,
    val soldCount: Int = 0,
    val earnedCoins: Long = 0L,
    val bestValue: Long = 0L,
    val speedLevel: Int = 0,
    val luckLevel: Int = 0,
    val capacityLevel: Int = 0,
    val autoSellLevel: Int = 0,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val darkTheme: Boolean = true,
    val languageEnglish: Boolean = false
)

private val Countries = listOf(
    Country("Россия", "Russia", "🇷🇺", "+7", 82.0, 0),
    Country("США", "USA", "🇺🇸", "+1", 10.0, 15),
    Country("Великобритания", "United Kingdom", "🇬🇧", "+44", 4.0, 50),
    Country("Япония", "Japan", "🇯🇵", "+81", 2.0, 100),
    Country("Германия", "Germany", "🇩🇪", "+49", 1.5, 175),
    Country("Канада", "Canada", "🇨🇦", "+1", 0.5, 300),
    Country("Anonymous", "Anonymous", "◉", "+888", 0.1, 500)
)

private enum class MenuPanel { NONE, STATS, SETTINGS, SOUND, THEME, LANGUAGE, HELP, ABOUT, CATALOG }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SimHunterApp() }
    }
}

@Composable
private fun SimHunterApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val initial = remember { loadSnapshot(context) }

    var selectedTab by remember { mutableIntStateOf(0) }
    var coins by remember { mutableLongStateOf(initial.coins) }
    val collection = remember { mutableStateListOf<PhoneNumber>().apply { addAll(initial.collection) } }
    var generatedCount by remember { mutableIntStateOf(initial.generatedCount) }
    var soldCount by remember { mutableIntStateOf(initial.soldCount) }
    var earnedCoins by remember { mutableLongStateOf(initial.earnedCoins) }
    var bestValue by remember { mutableLongStateOf(initial.bestValue) }
    var speedLevel by remember { mutableIntStateOf(initial.speedLevel) }
    var luckLevel by remember { mutableIntStateOf(initial.luckLevel) }
    var capacityLevel by remember { mutableIntStateOf(initial.capacityLevel) }
    var autoSellLevel by remember { mutableIntStateOf(initial.autoSellLevel) }
    var soundEnabled by remember { mutableStateOf(initial.soundEnabled) }
    var vibrationEnabled by remember { mutableStateOf(initial.vibrationEnabled) }
    var darkTheme by remember { mutableStateOf(initial.darkTheme) }
    var languageEnglish by remember { mutableStateOf(initial.languageEnglish) }
    var generated by remember { mutableStateOf<PhoneNumber?>(null) }
    var spinning by remember { mutableStateOf(false) }
    var displayNumber by remember { mutableStateOf("+7 900-000-00-00") }
    var details by remember { mutableStateOf<PhoneNumber?>(null) }
    var menuPanel by remember { mutableStateOf(MenuPanel.NONE) }
    var pendingResult by remember { mutableStateOf<PhoneNumber?>(null) }
    var spinJob by remember { mutableStateOf<Job?>(null) }
    val scope = rememberCoroutineScope()

    val pools = remember { Countries.associate { it.key to buildPool(it) } }
    val unlockedCountries by remember {
        derivedStateOf {
            Countries.filter { collection.size >= it.unlockAt }
        }
    }
    val capacity by remember {
        derivedStateOf {
            when (capacityLevel) {
                0 -> 100
                1 -> 250
                2 -> 500
                else -> 1000
            }
        }
    }
    val appLevel by remember { derivedStateOf { 1 + generatedCount / 50 } }

    fun saveNow() {
        saveSnapshot(
            context,
            GameSnapshot(
                coins = coins,
                collection = collection.toList(),
                generatedCount = generatedCount,
                soldCount = soldCount,
                earnedCoins = earnedCoins,
                bestValue = bestValue,
                speedLevel = speedLevel,
                luckLevel = luckLevel,
                capacityLevel = capacityLevel,
                autoSellLevel = autoSellLevel,
                soundEnabled = soundEnabled,
                vibrationEnabled = vibrationEnabled,
                darkTheme = darkTheme,
                languageEnglish = languageEnglish
            )
        )
    }

    LaunchedEffect(
        coins, collection.size, generatedCount, soldCount, earnedCoins, bestValue,
        speedLevel, luckLevel, capacityLevel, autoSellLevel, soundEnabled,
        vibrationEnabled, darkTheme, languageEnglish
    ) { saveNow() }

    DisposableEffect(Unit) {
        onDispose { saveNow() }
    }

    fun showFeedback(revealed: PhoneNumber) {
        if (soundEnabled) playSound(context, rare = revealed.stars >= 4)
        if (vibrationEnabled) vibrate(context, strong = revealed.stars >= 4)
    }

    fun pickCountry(): Country {
        val candidates = unlockedCountries.ifEmpty { listOf(Countries.first()) }
        val total = candidates.sumOf { it.baseChance }
        var roll = Random.nextDouble() * total
        for (country in candidates) {
            roll -= country.baseChance
            if (roll <= 0.0) return country
        }
        return candidates.last()
    }

    fun drawFromPool(country: Country): PhoneNumber? {
        val pool = pools.getValue(country.key)
        val used = collection.asSequence()
            .filter { it.country.key == country.key }
            .map { it.localDigits }
            .toSet()
        val remaining = pool.filterNot { used.contains(it.localDigits) }
        if (remaining.isEmpty()) return null

        val beautiful = remaining.filter { it.beautiful }
        val ordinary = remaining.filterNot { it.beautiful }
        val desiredBeautifulChance = min(0.22, 0.20 + luckLevel * 0.004)
        val chosen = when {
            beautiful.isEmpty() -> ordinary.random()
            ordinary.isEmpty() -> beautiful.random()
            Random.nextDouble() < desiredBeautifulChance -> beautiful.random()
            else -> ordinary.random()
        }
        return PhoneNumber(
            country = country,
            localDigits = chosen.localDigits,
            rarity = chosen.rarity,
            stars = chosen.stars,
            pattern = chosen.pattern,
            estimatedValue = chosen.estimatedValue
        )
    }

    fun drawNumber(): PhoneNumber {
        repeat(10) {
            val country = pickCountry()
            drawFromPool(country)?.let { return it }
        }
        return drawFromPool(Countries.first())
            ?: PhoneNumber(Countries.first(), "9000000000", "ОБЫЧНЫЙ", 1, "Обычный", 300)
    }

    fun previewNumber(): String {
        val country = pickCountry()
        return formatPhone(country, generatePreviewDigits(country))
    }

    fun reveal(result: PhoneNumber) {
        spinning = false
        pendingResult = null
        generated = result
        displayNumber = result.fullDisplay()
        generatedCount += 1
        bestValue = max(bestValue, result.estimatedValue)
        showFeedback(result)

        if (autoSellLevel > 0 && result.rarity == "ОБЫЧНЫЙ") {
            coins += result.saleCoins
            soldCount += 1
            earnedCoins += result.saleCoins
            generated = null
            android.widget.Toast.makeText(context, "Обычный номер продан • +${result.saleCoins} монет", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    fun startSpin() {
        if (spinning || coins < GENERATION_COST || collection.size >= capacity && autoSellLevel == 0) {
            if (coins < GENERATION_COST) {
                android.widget.Toast.makeText(context, "Нужно $GENERATION_COST монет для прокрута", android.widget.Toast.LENGTH_SHORT).show()
            } else if (collection.size >= capacity) {
                android.widget.Toast.makeText(context, "Коллекция заполнена. Продай находку или улучши вместимость.", android.widget.Toast.LENGTH_SHORT).show()
            }
            return
        }
        coins -= GENERATION_COST
        generated = null
        pendingResult = drawNumber()
        spinning = true
        spinJob?.cancel()
        spinJob = scope.launch {
            val duration = max(650L, 1650L - speedLevel * 180L)
            val started = System.currentTimeMillis()
            while (spinning && System.currentTimeMillis() - started < duration) {
                displayNumber = previewNumber()
                if (soundEnabled && (System.currentTimeMillis() - started) % 180L < 55L) playTick(context)
                delay(max(35L, 80L - speedLevel * 8L))
            }
            if (spinning) {
                pendingResult?.let { reveal(it) }
            }
        }
    }

    fun stopSpin() {
        if (!spinning) return
        spinJob?.cancel()
        pendingResult?.let { reveal(it) }
    }

    fun sellNumber(number: PhoneNumber) {
        val index = collection.indexOfFirst { it.id == number.id }
        if (index >= 0) {
            collection.removeAt(index)
            coins += number.saleCoins
            soldCount += 1
            earnedCoins += number.saleCoins
            details = null
            android.widget.Toast.makeText(context, "Продано • +${number.saleCoins} монет", android.widget.Toast.LENGTH_SHORT).show()
            if (soundEnabled) playTick(context)
            if (vibrationEnabled) vibrate(context, strong = false)
        }
    }

    fun collectNumber() {
        generated?.let { result ->
            if (collection.size < capacity) {
                collection.add(0, result)
                generated = null
                android.widget.Toast.makeText(context, "Добавлено в коллекцию • ${collection.size}/$capacity", android.widget.Toast.LENGTH_SHORT).show()
                if (soundEnabled) playTick(context)
                if (vibrationEnabled) vibrate(context, strong = false)
            }
        }
    }

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            background = DarkBackground,
            surface = DarkSurface,
            surfaceVariant = DarkSurface2,
            primary = TextMain,
            secondary = Accent,
            tertiary = AccentPurple
        )
    } else {
        lightColorScheme(
            background = Color(0xFFF6F8FB),
            surface = Color.White,
            surfaceVariant = Color(0xFFEFF3F7),
            primary = Color(0xFF18202A),
            secondary = Color(0xFF247FAF),
            tertiary = Color(0xFF7257BA)
        )
    }

    MaterialTheme(colorScheme = colorScheme) {
        val labels = strings(languageEnglish)
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    BottomBar(selectedTab, onTab = {
                        if (!spinning) selectedTab = it
                    }, labels = labels)
                }
            ) { padding ->
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .safeDrawingPadding()
                ) {
                    Crossfade(targetState = selectedTab, animationSpec = tween(250), label = "screen") { tab ->
                        when (tab) {
                            0 -> GeneratorScreen(
                                coins = coins,
                                level = appLevel,
                                generated = generated,
                                spinning = spinning,
                                displayNumber = displayNumber,
                                unlockedCountries = unlockedCountries,
                                capacity = capacity,
                                collectionSize = collection.size,
                                languageEnglish = languageEnglish,
                                onGenerate = { startSpin() },
                                onStopSpin = { stopSpin() },
                                onCollect = { collectNumber() },
                                onSell = { generated?.let { result -> coins += result.saleCoins; soldCount += 1; earnedCoins += result.saleCoins; generated = null; android.widget.Toast.makeText(context, "Продано • +${result.saleCoins} монет", android.widget.Toast.LENGTH_SHORT).show() } },
                                onDetails = { details = it }
                            )

                            1 -> CollectionScreen(
                                collection = collection,
                                capacity = capacity,
                                languageEnglish = languageEnglish,
                                onDetails = { details = it },
                                onSell = { sellNumber(it) }
                            )

                            2 -> UpgradesScreen(
                                coins = coins,
                                speedLevel = speedLevel,
                                luckLevel = luckLevel,
                                capacityLevel = capacityLevel,
                                autoSellLevel = autoSellLevel,
                                languageEnglish = languageEnglish,
                                onBuySpeed = {
                                    val cost = upgradeCost(speedLevel)
                                    if (speedLevel < 5 && coins >= cost) { coins -= cost; speedLevel += 1 }
                                    else android.widget.Toast.makeText(context, "Недостаточно монет или достигнут максимум", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                onBuyLuck = {
                                    val cost = upgradeCost(luckLevel) * 2
                                    if (luckLevel < 5 && coins >= cost) { coins -= cost; luckLevel += 1 }
                                    else android.widget.Toast.makeText(context, "Недостаточно монет или достигнут максимум", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                onBuyCapacity = {
                                    val cost = listOf(0L, 500L, 1500L, 5000L).getOrElse(capacityLevel) { 0L }
                                    if (capacityLevel < 3 && coins >= cost && cost > 0) { coins -= cost; capacityLevel += 1 }
                                    else android.widget.Toast.makeText(context, "Недостаточно монет или достигнут максимум", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                onBuyAutoSell = {
                                    val cost = 2500L * (autoSellLevel + 1)
                                    if (autoSellLevel < 1 && coins >= cost) { coins -= cost; autoSellLevel += 1 }
                                    else android.widget.Toast.makeText(context, "Автопродажа уже включена или не хватает монет", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            )

                            3 -> ShopScreen(
                                coins = coins,
                                languageEnglish = languageEnglish,
                                onPack = { pack ->
                                    android.widget.Toast.makeText(context, "Платежи отключены в бета-версии • пакет $pack", android.widget.Toast.LENGTH_LONG).show()
                                }
                            )

                            else -> MenuScreen(
                                collection = collection,
                                generatedCount = generatedCount,
                                soldCount = soldCount,
                                earnedCoins = earnedCoins,
                                bestValue = bestValue,
                                soundEnabled = soundEnabled,
                                vibrationEnabled = vibrationEnabled,
                                darkTheme = darkTheme,
                                languageEnglish = languageEnglish,
                                onPanel = { menuPanel = it }
                            )
                        }
                    }

                    if (spinning) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .zIndex(20f)
                                .pointerInput(Unit) {
                                    detectTapGestures { stopSpin() }
                                }
                        )
                    }
                }
            }
        }

        if (details != null) {
            NumberDetailsSheet(
                number = details!!,
                languageEnglish = languageEnglish,
                onDismiss = { details = null },
                onSell = { sellNumber(details!!) }
            )
        }

        if (menuPanel != MenuPanel.NONE) {
            MenuPanelSheet(
                panel = menuPanel,
                languageEnglish = languageEnglish,
                soundEnabled = soundEnabled,
                vibrationEnabled = vibrationEnabled,
                darkTheme = darkTheme,
                generatedCount = generatedCount,
                soldCount = soldCount,
                earnedCoins = earnedCoins,
                bestValue = bestValue,
                collection = collection,
                onDismiss = { menuPanel = MenuPanel.NONE },
                onOpenPanel = { menuPanel = it },
                onSound = { soundEnabled = !soundEnabled },
                onVibration = { vibrationEnabled = !vibrationEnabled },
                onTheme = { darkTheme = !darkTheme },
                onLanguage = { languageEnglish = !languageEnglish }
            )
        }
    }
}

@Composable
private fun GeneratorScreen(
    coins: Long,
    level: Int,
    generated: PhoneNumber?,
    spinning: Boolean,
    displayNumber: String,
    unlockedCountries: List<Country>,
    capacity: Int,
    collectionSize: Int,
    languageEnglish: Boolean,
    onGenerate: () -> Unit,
    onStopSpin: () -> Unit,
    onCollect: () -> Unit,
    onSell: () -> Unit,
    onDetails: (PhoneNumber) -> Unit
) {
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 1f,
        targetValue = 1.018f,
        animationSpec = infiniteRepeatable(tween(950), RepeatMode.Reverse),
        label = "pulseScale"
    )
    val spinScale by animateFloatAsState(
        targetValue = if (spinning) 1.03f else 1f,
        animationSpec = tween(120),
        label = "spinScale"
    )

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    if (languageEnglish) "Generation" else "Генерация",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (languageEnglish) "LEVEL" else "УРОВЕНЬ",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(level.toString(), color = Accent, fontWeight = FontWeight.Bold)
                }
            }
            Text(
                "◉ $coins",
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.height(14.dp))

        Text(
            if (spinning) {
                if (languageEnglish) "TAP ANYWHERE TO STOP" else "КОСНИСЬ ЛЮБОЙ ЧАСТИ ЭКРАНА — СТОП"
            } else if (generated != null) {
                if (languageEnglish) "NEW NUMBER" else "НОВЫЙ НОМЕР"
            } else {
                if (languageEnglish) "GENERATION POOL" else "СИСТЕМА ГЕНЕРАЦИИ"
            },
            color = if (spinning) Accent else MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.Black,
            fontSize = 14.sp,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        Spacer(Modifier.height(14.dp))

        Box(
            Modifier
                .fillMaxWidth()
                .scale(if (generated == null && !spinning) pulse else 1f)
                .scale(spinScale)
                .background(
                    Brush.verticalGradient(
                        listOf(
                            MaterialTheme.colorScheme.surfaceVariant,
                            MaterialTheme.colorScheme.surface
                        )
                    ),
                    RoundedCornerShape(28.dp)
                )
                .clip(RoundedCornerShape(28.dp))
                .then(
                    if (generated != null && !spinning) {
                        Modifier.combinedClickable(
                            onClick = {},
                            onLongClick = { onDetails(generated) }
                        )
                    } else Modifier
                )
                .padding(horizontal = 18.dp, vertical = 24.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                if (generated != null && !spinning) {
                    AnimatedVisibility(visible = true) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(generated.country.flag, fontSize = 30.sp)
                            Text(
                                localizedCountry(generated.country, languageEnglish) + "  ${generated.country.code}",
                                color = TextMuted,
                                fontSize = 14.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        generated.fullDisplay(),
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(10.dp))
                    RarityChip(generated.rarity, generated.stars)
                    Spacer(Modifier.height(11.dp))
                    Text(
                        "${generated.estimatedValue} ₽",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (languageEnglish) "Hold the number for details" else "Зажми номер — подробности",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                } else {
                    Text(if (spinning) "◉" else "SIM HUNTER", color = Accent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    AnimatedContent(targetState = displayNumber, label = "numberTicker") { value ->
                        Text(
                            value,
                            fontSize = if (spinning) 28.sp else 27.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.graphicsLayer { rotationZ = if (spinning) -1f else 0f }
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (spinning) (if (languageEnglish) "spinning..." else "прокрутка…") else (if (languageEnglish) "Find one of 1,000 numbers" else "Найди один из 1 000 номеров"),
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        if (generated != null && !spinning) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = onSell,
                    modifier = Modifier.weight(0.8f).height(54.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Sell, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(7.dp))
                    Text(if (languageEnglish) "SELL" else "ПРОДАТЬ", fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = onCollect,
                    modifier = Modifier.weight(1.2f).height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.background)
                ) {
                    Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(7.dp))
                    Text(if (languageEnglish) "COLLECT" else "В КОЛЛЕКЦИЮ", fontWeight = FontWeight.Black)
                }
            }
        } else {
            Button(
                onClick = onGenerate,
                modifier = Modifier.fillMaxWidth().height(58.dp),
                enabled = !spinning,
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.background
                )
            ) {
                Icon(Icons.Default.PhonelinkRing, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (languageEnglish) "GENERATE • 50" else "КРУТИТЬ • 50 МОНЕТ", fontWeight = FontWeight.Black)
            }
        }

        Spacer(Modifier.height(10.dp))

        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(14.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        if (languageEnglish) "POOL" else "ПУЛ ГЕНЕРАЦИИ",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text("${collectionSize}/$capacity", color = Accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Spacer(Modifier.height(8.dp))
                unlockedCountries.forEach { country ->
                    val chance = normalizedChance(country, unlockedCountries)
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(country.flag, fontSize = 17.sp)
                        Spacer(Modifier.width(7.dp))
                        Text(localizedCountry(country, languageEnglish), Modifier.weight(1f), fontSize = 12.sp)
                        Text("${formatChance(chance)}%", color = TextMuted, fontSize = 11.sp)
                    }
                }
                Divider(Modifier.padding(vertical = 7.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                Text(
                    if (languageEnglish) "Unlocking adds a country to the random pool; it does not guarantee a drop." else "Разблокировка только добавляет страну в случайный пул — выпадение не гарантируется.",
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CollectionScreen(
    collection: List<PhoneNumber>,
    capacity: Int,
    languageEnglish: Boolean,
    onDetails: (PhoneNumber) -> Unit,
    onSell: (PhoneNumber) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
            Column {
                Text(if (languageEnglish) "Collection" else "Коллекция", fontSize = 32.sp, fontWeight = FontWeight.Black)
                Text("${collection.size} / $capacity", color = TextMuted)
            }
            Text("${collection.count { it.rarity != "ОБЫЧНЫЙ" }} ${if (languageEnglish) "rare" else "редких"}", color = Accent, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))

        if (collection.isEmpty()) {
            EmptyState(
                title = if (languageEnglish) "Collection is empty" else "Коллекция пуста",
                text = if (languageEnglish) "Generate a number, then collect it." else "Сгенерируй номер и добавь его в коллекцию."
            )
        } else {
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(collection, key = { it.id }) { number ->
                    Card(
                        Modifier
                            .fillMaxWidth()
                            .combinedClickable(
                                onClick = {},
                                onLongClick = { onDetails(number) }
                            ),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(number.country.flag, fontSize = 25.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(number.fullDisplay(), fontWeight = FontWeight.ExtraBold)
                                Text(localizedCountry(number.country, languageEnglish), color = TextMuted, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(number.rarity, color = rarityColor(number.rarity), fontSize = 10.sp, fontWeight = FontWeight.Black)
                                Text("${number.saleCoins} ◉", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (languageEnglish) "Hold any number for full details and selling." else "Зажми любой номер — откроются подробности и продажа.",
                color = TextMuted,
                fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun UpgradesScreen(
    coins: Long,
    speedLevel: Int,
    luckLevel: Int,
    capacityLevel: Int,
    autoSellLevel: Int,
    languageEnglish: Boolean,
    onBuySpeed: () -> Unit,
    onBuyLuck: () -> Unit,
    onBuyCapacity: () -> Unit,
    onBuyAutoSell: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text(if (languageEnglish) "Upgrades" else "Улучшения", fontSize = 32.sp, fontWeight = FontWeight.Black)
        Text("◉ $coins", color = TextMuted)
        Spacer(Modifier.height(14.dp))

        UpgradeCard(
            icon = Icons.Default.Speed,
            title = if (languageEnglish) "Generation speed" else "Скорость генерации",
            subtitle = if (languageEnglish) "Shorter spin animation" else "Сокращает время прокрутки",
            level = speedLevel,
            maxLevel = 5,
            cost = if (speedLevel < 5) upgradeCost(speedLevel) else 0,
            onClick = onBuySpeed
        )
        UpgradeCard(
            icon = Icons.Default.Bolt,
            title = if (languageEnglish) "Rare chance" else "Шанс на редкие",
            subtitle = if (languageEnglish) "Very slightly increases beautiful-number chance" else "Очень немного повышает шанс на красивые номера",
            level = luckLevel,
            maxLevel = 5,
            cost = if (luckLevel < 5) upgradeCost(luckLevel) * 2 else 0,
            onClick = onBuyLuck
        )
        UpgradeCard(
            icon = Icons.Default.Inventory2,
            title = if (languageEnglish) "Collection capacity" else "Максимум коллекции",
            subtitle = if (languageEnglish) "More slots for unique finds" else "Больше мест для уникальных находок",
            level = capacityLevel,
            maxLevel = 3,
            cost = when (capacityLevel) { 0 -> 500; 1 -> 1500; 2 -> 5000; else -> 0 },
            onClick = onBuyCapacity,
            trailingText = when (capacityLevel) { 0 -> "100"; 1 -> "250"; 2 -> "500"; else -> "1000" }
        )
        UpgradeCard(
            icon = Icons.Default.AutoMode,
            title = if (languageEnglish) "Auto-sell common" else "Автопродажа обычных",
            subtitle = if (languageEnglish) "Common finds are sold immediately" else "Обычные находки продаются сразу после раскрытия",
            level = autoSellLevel,
            maxLevel = 1,
            cost = if (autoSellLevel == 0) 2500 else 0,
            onClick = onBuyAutoSell
        )
    }
}

@Composable
private fun UpgradeCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    level: Int,
    maxLevel: Int,
    cost: Long,
    onClick: () -> Unit,
    trailingText: String? = null
) {
    Card(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .animateContentSize(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) { Icon(icon, null, tint = Accent) }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.ExtraBold)
                    Text(subtitle, color = TextMuted, fontSize = 11.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("$level/$maxLevel", color = Accent, fontWeight = FontWeight.Black)
                    if (trailingText != null) Text(trailingText, color = TextMuted, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { level.toFloat() / maxLevel.coerceAtLeast(1) },
                modifier = Modifier.fillMaxWidth().height(5.dp),
                color = Accent,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
            Spacer(Modifier.height(11.dp))
            Button(
                onClick = onClick,
                modifier = Modifier.fillMaxWidth().height(44.dp),
                shape = RoundedCornerShape(13.dp),
                enabled = level < maxLevel,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.background)
            ) {
                Text(if (level >= maxLevel) "МАКСИМУМ" else "УЛУЧШИТЬ • $cost ◉", fontWeight = FontWeight.Black, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun ShopScreen(
    coins: Long,
    languageEnglish: Boolean,
    onPack: (String) -> Unit
) {
    val packs = listOf("100 монет" to "99 ₽", "500 монет" to "399 ₽", "1 250 монет" to "799 ₽", "5 000 монет" to "2 999 ₽")
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text(if (languageEnglish) "Shop" else "Магазин", fontSize = 32.sp, fontWeight = FontWeight.Black)
        Text("◉ $coins", color = TextMuted)
        Text(if (languageEnglish) "Coin packs" else "Пакеты игровой валюты", color = TextMuted)
        Spacer(Modifier.height(14.dp))
        packs.forEach { (amount, price) ->
            Card(
                Modifier.fillMaxWidth().padding(bottom = 10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ShoppingBag, null, tint = Accent)
                    Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) {
                        Text(amount, fontWeight = FontWeight.Black)
                        Text(price, color = TextMuted, fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = { onPack(amount) }, shape = RoundedCornerShape(12.dp)) {
                        Text(if (languageEnglish) "BUY" else "КУПИТЬ", fontWeight = FontWeight.Black)
                    }
                }
            }
        }
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Text(
                if (languageEnglish) "Payments are intentionally disabled in beta. The shop is ready for a real billing connection." else "Платежи в бете намеренно отключены. Магазин уже готов для подключения настоящих покупок.",
                color = TextMuted,
                fontSize = 11.sp,
                modifier = Modifier.padding(14.dp)
            )
        }
    }
}

@Composable
private fun MenuScreen(
    collection: List<PhoneNumber>,
    generatedCount: Int,
    soldCount: Int,
    earnedCoins: Long,
    bestValue: Long,
    soundEnabled: Boolean,
    vibrationEnabled: Boolean,
    darkTheme: Boolean,
    languageEnglish: Boolean,
    onPanel: (MenuPanel) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text(if (languageEnglish) "Menu" else "Меню", fontSize = 32.sp, fontWeight = FontWeight.Black)
        Text("SIM HUNTER v$VERSION", color = TextMuted)
        Spacer(Modifier.height(14.dp))

        val entries = listOf(
            Triple(MenuPanel.STATS, Icons.Default.Analytics, if (languageEnglish) "Statistics" else "Статистика"),
            Triple(MenuPanel.SETTINGS, Icons.Default.Settings, if (languageEnglish) "Settings" else "Настройки"),
            Triple(MenuPanel.SOUND, Icons.Default.VolumeUp, if (languageEnglish) "Sound & vibration" else "Звук и вибрация"),
            Triple(MenuPanel.THEME, Icons.Default.Palette, if (languageEnglish) "Theme" else "Тема"),
            Triple(MenuPanel.LANGUAGE, Icons.Default.Language, if (languageEnglish) "Language" else "Язык"),
            Triple(MenuPanel.CATALOG, Icons.Default.Inventory2, if (languageEnglish) "Catalog" else "Каталог"),
            Triple(MenuPanel.HELP, Icons.Default.Info, if (languageEnglish) "Help" else "Помощь"),
            Triple(MenuPanel.ABOUT, Icons.Default.Info, if (languageEnglish) "About app" else "О приложении")
        )

        LazyColumn(
            Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            items(entries) { (panel, icon, title) ->
                Card(
                    Modifier.fillMaxWidth().combinedClickable(onClick = { onPanel(panel) }, onLongClick = { onPanel(panel) }),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(icon, null, tint = Accent)
                        Spacer(Modifier.width(13.dp))
                        Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        Text("›", color = TextMuted, fontSize = 24.sp)
                    }
                }
            }
        }

        Text(
            if (languageEnglish) "Collection: ${collection.size} • Generated: $generatedCount • Sold: $soldCount" else "В коллекции: ${collection.size} • Сгенерировано: $generatedCount • Продано: $soldCount",
            color = Accent,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 8.dp)
        )
        Text(
            if (languageEnglish) "Sound ${if (soundEnabled) "ON" else "OFF"} • Vibration ${if (vibrationEnabled) "ON" else "OFF"} • ${if (darkTheme) "Dark" else "Light"} • ${if (languageEnglish) "EN" else "RU"}" else "Звук ${if (soundEnabled) "ВКЛ" else "ВЫКЛ"} • Вибрация ${if (vibrationEnabled) "ВКЛ" else "ВЫКЛ"} • ${if (darkTheme) "Тёмная" else "Светлая"} • ${if (languageEnglish) "EN" else "RU"}",
            color = TextMuted,
            fontSize = 10.sp,
            modifier = Modifier.padding(top = 3.dp)
        )
        if (bestValue > 0L) {
            Text(
                if (languageEnglish) "Best find: $bestValue ₽ • Earned: $earnedCoins ◉" else "Лучшая находка: $bestValue ₽ • Заработано: $earnedCoins ◉",
                color = TextMuted,
                fontSize = 10.sp,
                modifier = Modifier.padding(top = 3.dp)
            )
        }
    }
}

@Composable
private fun MenuPanelSheet(
    panel: MenuPanel,
    languageEnglish: Boolean,
    soundEnabled: Boolean,
    vibrationEnabled: Boolean,
    darkTheme: Boolean,
    generatedCount: Int,
    soldCount: Int,
    earnedCoins: Long,
    bestValue: Long,
    collection: List<PhoneNumber>,
    onDismiss: () -> Unit,
    onOpenPanel: (MenuPanel) -> Unit,
    onSound: () -> Unit,
    onVibration: () -> Unit,
    onTheme: () -> Unit,
    onLanguage: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp).windowInsetsPadding(WindowInsets.navigationBars)) {
            when (panel) {
                MenuPanel.STATS -> {
                    SheetTitle(if (languageEnglish) "Statistics" else "Статистика", Icons.Default.Analytics)
                    StatRow(if (languageEnglish) "Generated" else "Сгенерировано", generatedCount.toString())
                    StatRow(if (languageEnglish) "Sold" else "Продано", soldCount.toString())
                    StatRow(if (languageEnglish) "In collection" else "В коллекции", collection.size.toString())
                    StatRow(if (languageEnglish) "Earned" else "Заработано", "$earnedCoins ◉")
                    StatRow(if (languageEnglish) "Best find" else "Лучшая находка", if (bestValue == 0L) "—" else "$bestValue ₽")
                }
                MenuPanel.SETTINGS -> {
                    SheetTitle(if (languageEnglish) "Settings" else "Настройки", Icons.Default.Settings)
                    SettingLine(if (languageEnglish) "Sound & vibration" else "Звук и вибрация", "›") { onOpenPanel(MenuPanel.SOUND) }
                    SettingSwitch(if (languageEnglish) "Sound" else "Звук", soundEnabled, onSound)
                    SettingSwitch(if (languageEnglish) "Vibration" else "Вибрация", vibrationEnabled, onVibration)
                    SettingSwitch(if (languageEnglish) "Dark theme" else "Тёмная тема", darkTheme, onTheme)
                    SettingLine(if (languageEnglish) "Language" else "Язык", if (languageEnglish) "English" else "Русский") { onLanguage() }
                }
                MenuPanel.SOUND -> {
                    SheetTitle(if (languageEnglish) "Sound & vibration" else "Звук и вибрация", Icons.Default.VolumeUp)
                    SettingSwitch(if (languageEnglish) "Sounds" else "Звуки", soundEnabled, onSound)
                    SettingSwitch(if (languageEnglish) "Vibration" else "Вибрация", vibrationEnabled, onVibration)
                    Text(if (languageEnglish) "A short tone plays on each reveal." else "Короткий звук играет при каждом раскрытии номера.", color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 18.dp))
                }
                MenuPanel.THEME -> {
                    SheetTitle(if (languageEnglish) "Theme" else "Тема", Icons.Default.Palette)
                    SettingSwitch(if (languageEnglish) "Dark" else "Тёмная", darkTheme, onTheme)
                    SettingSwitch(if (languageEnglish) "Light" else "Светлая", !darkTheme, onTheme)
                    Spacer(Modifier.height(18.dp))
                }
                MenuPanel.LANGUAGE -> {
                    SheetTitle(if (languageEnglish) "Language" else "Язык", Icons.Default.Language)
                    SettingLine("Русский", if (!languageEnglish) "Выбрано" else "") { if (languageEnglish) onLanguage() }
                    SettingLine("English", if (languageEnglish) "Selected" else "") { if (!languageEnglish) onLanguage() }
                    Spacer(Modifier.height(18.dp))
                }
                MenuPanel.CATALOG -> {
                    SheetTitle(if (languageEnglish) "Catalog" else "Каталог", Icons.Default.Inventory2)
                    Text(if (languageEnglish) "Countries" else "Страны", fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(8.dp))
                    Countries.forEach { country ->
                        val found = collection.count { it.country.key == country.key }
                        val unlocked = collection.size >= country.unlockAt
                        Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(country.flag, fontSize = 19.sp)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(localizedCountry(country, languageEnglish), fontWeight = FontWeight.Bold)
                                Text(if (unlocked) "$found / 1000" else "${if (languageEnglish) "Unlock at" else "Открывается на"} ${country.unlockAt}", color = TextMuted, fontSize = 10.sp)
                            }
                            Text(if (unlocked) "${formatChance(normalizedChance(country, Countries.filter { collection.size >= it.unlockAt }))}%" else "🔒", color = if (unlocked) Accent else TextMuted, fontSize = 11.sp)
                        }
                    }
                    Divider(Modifier.padding(vertical = 8.dp))
                    Text(if (languageEnglish) "Rarity" else "Редкости", fontWeight = FontWeight.Black)
                    listOf(
                        "ОБЫЧНЫЙ" to 800,
                        "НЕОБЫЧНЫЙ" to 90,
                        "РЕДКИЙ" to 60,
                        "ЭПИЧЕСКИЙ" to 35,
                        "ЛЕГЕНДАРНЫЙ" to 12,
                        "УЛЬТРАРЕДКИЙ" to 3
                    ).forEach { (rarity, count) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(rarity, color = rarityColor(rarity), modifier = Modifier.weight(1f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("$count / 1000", color = TextMuted, fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                }
                MenuPanel.HELP -> {
                    SheetTitle(if (languageEnglish) "How it works" else "Как это работает", Icons.Default.Settings)
                    HelpLine("1", if (languageEnglish) "Press Generate to start the roulette." else "Нажми «Крутить», чтобы начать прокрутку.")
                    HelpLine("2", if (languageEnglish) "Tap anywhere while spinning to reveal immediately." else "Во время прокрутки коснись любой части экрана — номер сразу раскроется.")
                    HelpLine("3", if (languageEnglish) "Sell first to get coins, or collect the number." else "Сначала можно продать номер и получить монеты, либо забрать его в коллекцию.")
                    HelpLine("4", if (languageEnglish) "Hold a number to open full details." else "Зажми номер, чтобы открыть полные подробности.")
                    HelpLine("5", if (languageEnglish) "Each country has a finite pool of 1,000 unique numbers." else "У каждой страны конечный пул из 1 000 уникальных номеров.")
                }
                MenuPanel.ABOUT -> {
                    SheetTitle(if (languageEnglish) "About SIM HUNTER" else "О SIM HUNTER", Icons.Default.Info)
                    Text("SIM HUNTER v$VERSION", fontSize = 20.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.height(6.dp))
                    Text(if (languageEnglish) "A number-hunting game with finite pools, rarity, collection and upgrades." else "Игра-охота за номерами с конечными пулами, редкостями, коллекцией и улучшениями.", color = TextMuted, fontSize = 12.sp)
                    Spacer(Modifier.height(16.dp))
                }
                else -> Unit
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun NumberDetailsSheet(
    number: PhoneNumber,
    languageEnglish: Boolean,
    onDismiss: () -> Unit,
    onSell: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp).windowInsetsPadding(WindowInsets.navigationBars)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(number.country.flag, fontSize = 30.sp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(number.fullDisplay(), fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Text(localizedCountry(number.country, languageEnglish), color = TextMuted)
                }
            }
            Spacer(Modifier.height(12.dp))
            RarityChip(number.rarity, number.stars)
            Spacer(Modifier.height(12.dp))
            StatRow(if (languageEnglish) "Pattern" else "Паттерн", number.pattern)
            StatRow(if (languageEnglish) "Estimated market value" else "Оценочная стоимость", "${number.estimatedValue} ₽")
            StatRow(if (languageEnglish) "Game sale reward" else "Награда за продажу", "+${number.saleCoins} ◉")
            StatRow(if (languageEnglish) "Pool" else "Пул", "1 000")
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = onSell,
                Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.background)
            ) {
                Icon(Icons.Default.Sell, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (languageEnglish) "SELL FOR +${number.saleCoins} COINS" else "ПРОДАТЬ ЗА +${number.saleCoins} МОНЕТ", fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.height(14.dp))
        }
    }
}

@Composable
private fun SheetTitle(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Accent)
        Spacer(Modifier.width(8.dp))
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextMuted, fontSize = 12.sp)
        Text(value, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChanged: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontWeight = FontWeight.Bold)
        Switch(checked = checked, onCheckedChange = { onChanged() })
    }
}

@Composable
private fun SettingLine(label: String, value: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontWeight = FontWeight.Bold)
            Text(value, color = Accent)
        }
    }
}

@Composable
private fun HelpLine(number: String, text: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.Top) {
        Text(number, color = Accent, fontWeight = FontWeight.Black, modifier = Modifier.width(25.dp))
        Text(text, color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp)
    }
}

@Composable
private fun RarityChip(rarity: String, stars: Int) {
    val c = rarityColor(rarity)
    Row(
        Modifier
            .clip(RoundedCornerShape(30.dp))
            .background(c.copy(alpha = 0.15f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(rarity, color = c, fontSize = 12.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.width(7.dp))
        Text("★".repeat(stars) + "☆".repeat(5 - stars), color = c, fontSize = 12.sp)
    }
}

@Composable
private fun EmptyState(title: String, text: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Inventory2, null, tint = Accent, modifier = Modifier.size(34.dp))
            Spacer(Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.Black, fontSize = 18.sp)
            Spacer(Modifier.height(5.dp))
            Text(text, color = TextMuted, textAlign = TextAlign.Center, fontSize = 12.sp)
        }
    }
}

@Composable
private fun BottomBar(selected: Int, onTab: (Int) -> Unit, labels: UiStrings) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp
    ) {
        val items = listOf(
            Triple(Icons.Default.Home, labels.home, "home"),
            Triple(Icons.Default.Inventory2, labels.collection, "collection"),
            Triple(Icons.Default.Upgrade, labels.upgrades, "upgrades"),
            Triple(Icons.Default.Storefront, labels.shop, "shop"),
            Triple(Icons.Default.Menu, labels.menu, "menu")
        )
        items.forEachIndexed { index, item ->
            NavigationBarItem(
                selected = selected == index,
                onClick = { onTab(index) },
                icon = { Icon(item.first, contentDescription = item.second, modifier = Modifier.size(20.dp)) },
                label = { Text(item.second, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            )
        }
    }
}

private data class UiStrings(
    val home: String,
    val collection: String,
    val upgrades: String,
    val shop: String,
    val menu: String
)

private fun strings(en: Boolean): UiStrings = if (en) {
    UiStrings("Home", "Collection", "Upgrades", "Shop", "Menu")
} else {
    UiStrings("Главная", "Коллекция", "Улучшения", "Магазин", "Меню")
}

private fun localizedCountry(country: Country, en: Boolean): String = if (en) country.nameEn else country.nameRu

private fun formatChance(chance: Double): String = if (chance >= 10) "%.1f".format(chance) else "%.2f".format(chance)

private fun normalizedChance(country: Country, unlocked: List<Country>): Double {
    val total = unlocked.sumOf { it.baseChance }.coerceAtLeast(0.001)
    return country.baseChance / total * 100.0
}

private fun rarityColor(rarity: String): Color = when (rarity) {
    "УЛЬТРАРЕДКИЙ" -> Color(0xFFFFB44B)
    "ЛЕГЕНДАРНЫЙ" -> Color(0xFFFF8B5E)
    "ЭПИЧЕСКИЙ" -> Color(0xFFB68CFF)
    "РЕДКИЙ" -> Color(0xFF6AB8FF)
    "НЕОБЫЧНЫЙ" -> Color(0xFF5ED9A6)
    else -> Color(0xFFA8B1BC)
}

private fun upgradeCost(level: Int): Long = when (level) {
    0 -> 250
    1 -> 650
    2 -> 1500
    3 -> 3200
    else -> 7000
}

private fun PhoneNumber.fullDisplay(): String = formatPhone(country, localDigits)

private fun formatPhone(country: Country, local: String): String {
    return when (country.code) {
        "+7" -> "+7 ${local.take(3)}-${local.drop(3).take(3)}-${local.drop(6).take(2)}-${local.drop(8).take(2)}"
        "+1" -> "+1 ${local.take(3)}-${local.drop(3).take(3)}-${local.drop(6).take(4)}"
        "+44", "+81", "+49" -> "+${country.code.drop(1)} ${local.take(3)}-${local.drop(3).take(3)}-${local.drop(6)}"
        "+888" -> "+888 ${local.take(2)}-${local.drop(2).take(3)}-${local.drop(5)}"
        else -> "${country.code} ${local.chunked(3).joinToString("-")}"
    }
}

private fun validFirstDigit(country: Country, random: Random): Char = when (country.code) {
    "+7", "+44" -> '7'
    "+1" -> ('2'..'9').random(random)
    "+81" -> ('7'..'9').random(random)
    "+49" -> listOf('1', '5', '6', '7').random(random)
    "+888" -> ('1'..'9').random(random)
    else -> ('1'..'9').random(random)
}

private fun generatePreviewDigits(country: Country): String {
    val len = 11 - country.code.count { it.isDigit() }
    val random = Random(System.nanoTime())
    return buildString {
        append(validFirstDigit(country, random))
        repeat(len - 1) { append(random.nextInt(0, 10)) }
    }
}

private fun buildPool(country: Country): List<PoolNumber> {
    val seed = (country.key.hashCode().toLong() shl 12) xor 0x5EEDL
    val random = Random(seed)
    val localLength = 11 - country.code.count { it.isDigit() }
    val used = HashSet<String>(1100)
    val result = ArrayList<PoolNumber>(1000)

    fun addBeautiful() {
        while (result.size < 200) {
            val beautifulIndex = result.size
            val rarity = when {
                beautifulIndex < 90 -> "НЕОБЫЧНЫЙ"
                beautifulIndex < 150 -> "РЕДКИЙ"
                beautifulIndex < 185 -> "ЭПИЧЕСКИЙ"
                beautifulIndex < 197 -> "ЛЕГЕНДАРНЫЙ"
                else -> "УЛЬТРАРЕДКИЙ"
            }
            val pattern = when (rarity) {
                "УЛЬТРАРЕДКИЙ" -> "Идеальный повтор"
                "ЛЕГЕНДАРНЫЙ" -> "Зеркало"
                "ЭПИЧЕСКИЙ" -> "Повтор блока"
                "РЕДКИЙ" -> "Серия / пары"
                else -> "Повтор цифр"
            }
            val candidate = makeBeautifulDigits(country, localLength, random, rarity)
            if (candidate != null && used.add(candidate)) {
                result += PoolNumber(
                    localDigits = candidate,
                    beautiful = true,
                    rarity = rarity,
                    stars = when (rarity) {
                        "УЛЬТРАРЕДКИЙ" -> 5
                        "ЛЕГЕНДАРНЫЙ" -> 5
                        "ЭПИЧЕСКИЙ" -> 4
                        "РЕДКИЙ" -> 3
                        else -> 2
                    },
                    pattern = pattern,
                    estimatedValue = estimateMarketValue(rarity, candidate)
                )
            }
        }
    }

    addBeautiful()

    while (result.size < 1000) {
        val candidate = buildString {
            append(validFirstDigit(country, random))
            repeat(localLength - 1) { append(random.nextInt(0, 10)) }
        }
        if (!used.add(candidate)) continue
        result += PoolNumber(
            localDigits = candidate,
            beautiful = false,
            rarity = "ОБЫЧНЫЙ",
            stars = 1,
            pattern = detectPattern(candidate).second,
            estimatedValue = estimateMarketValue("ОБЫЧНЫЙ", candidate)
        )
    }
    return result.shuffled(Random(seed xor 0x77EEL))
}

private fun makeBeautifulDigits(country: Country, length: Int, random: Random, rarity: String): String? {
    val type = when (rarity) {
        "УЛЬТРАРЕДКИЙ" -> random.nextInt(0, 3)
        "ЛЕГЕНДАРНЫЙ" -> random.nextInt(0, 4)
        "ЭПИЧЕСКИЙ" -> random.nextInt(0, 5)
        else -> random.nextInt(0, 7)
    }
    val nonZero = validFirstDigit(country, random)
    val chars = CharArray(length) { ('0'..'9').random(random) }
    chars[0] = nonZero

    when (type) {
        0 -> {
            val d = ('0'..'9').random(random)
            chars.fill(d)
            chars[0] = if (d == '0') nonZero else d
        }
        1 -> {
            val a = ('1'..'9').random(random)
            val b = ('0'..'9').random(random)
            for (i in chars.indices) chars[i] = if (i % 4 < 2) a else b
            chars[0] = a
        }
        2 -> {
            val half = (length + 1) / 2
            val first = CharArray(half) { ('0'..'9').random(random) }
            first[0] = nonZero
            for (i in 0 until half) chars[i] = first[i]
            for (i in half until length) chars[i] = first[length - 1 - i]
        }
        3 -> {
            val d = ('0'..'9').random(random)
            for (i in chars.indices) chars[i] = if (i >= length - 4) d else ('0'..'9').random(random)
            chars[0] = nonZero
        }
        4 -> {
            val start = random.nextInt(1, 6)
            val step = if (random.nextBoolean()) 1 else -1
            for (i in chars.indices) chars[i] = ((start + i * step).floorMod(10) + '0'.code).toChar()
            chars[0] = if (chars[0] == '0') nonZero else chars[0]
        }
        5 -> {
            val a = ('1'..'9').random(random)
            val b = ('0'..'9').random(random)
            val c = ('0'..'9').random(random)
            val block = charArrayOf(a, b, c)
            for (i in chars.indices) chars[i] = block[i % block.size]
        }
        else -> {
            val a = ('1'..'9').random(random)
            val b = ('0'..'9').random(random)
            val end = min(4, length)
            for (i in 0 until end) chars[length - end + i] = if (i % 2 == 0) a else b
            chars[0] = nonZero
        }
    }
    return String(chars)
}

private fun Int.floorMod(mod: Int): Int = ((this % mod) + mod) % mod

private fun detectPattern(digits: String): Pair<Int, String> {
    var bestScore = 0
    var bestName = "Обычный"
    if (digits.any { ch -> digits.count { it == ch } >= 6 }) {
        bestScore = 6
        bestName = "Много повторов"
    }
    if (digits == digits.reversed() && digits.length >= 7) {
        bestScore = max(bestScore, 6)
        bestName = "Палиндром"
    }
    if (digits.contains("777") || digits.contains("888") || digits.contains("999")) {
        bestScore = max(bestScore, 3)
        bestName = "Тройной повтор"
    }
    val tail = digits.takeLast(min(6, digits.length))
    if (tail.take(2).repeat(3).length <= digits.length && digits.endsWith(tail.take(2).repeat(3))) {
        bestScore = max(bestScore, 4)
        bestName = "Повтор блока"
    }
    var up = true
    var down = true
    for (i in 1 until digits.length) {
        val prev = digits[i - 1].digitToInt()
        val cur = digits[i].digitToInt()
        up = up && ((cur - prev + 10) % 10 == 1)
        down = down && ((prev - cur + 10) % 10 == 1)
    }
    if ((up || down) && digits.length >= 6) {
        bestScore = max(bestScore, 5)
        bestName = "Последовательность"
    }
    return bestScore to bestName
}

private fun estimateMarketValue(rarity: String, digits: String): Long {
    val (minValue, maxValue) = when (rarity) {
        "НЕОБЫЧНЫЙ" -> 1200L to 15000L
        "РЕДКИЙ" -> 15000L to 120000L
        "ЭПИЧЕСКИЙ" -> 120000L to 500000L
        "ЛЕГЕНДАРНЫЙ" -> 500000L to 2200000L
        "УЛЬТРАРЕДКИЙ" -> 2200000L to 8000000L
        else -> 150L to 2000L
    }
    val hash = digits.hashCode().toUInt().toLong()
    return minValue + (hash % (maxValue - minValue + 1))
}

private fun saveSnapshot(context: Context, snapshot: GameSnapshot) {
    val prefs = context.getSharedPreferences("sim_hunter", Context.MODE_PRIVATE)
    val array = JSONArray()
    snapshot.collection.forEach { number ->
        array.put(
            JSONObject()
                .put("country", number.country.key)
                .put("digits", number.localDigits)
                .put("rarity", number.rarity)
                .put("stars", number.stars)
                .put("pattern", number.pattern)
                .put("value", number.estimatedValue)
        )
    }
    prefs.edit()
        .putLong("coins", snapshot.coins)
        .putString("collection", array.toString())
        .putInt("generatedCount", snapshot.generatedCount)
        .putInt("soldCount", snapshot.soldCount)
        .putLong("earnedCoins", snapshot.earnedCoins)
        .putLong("bestValue", snapshot.bestValue)
        .putInt("speedLevel", snapshot.speedLevel)
        .putInt("luckLevel", snapshot.luckLevel)
        .putInt("capacityLevel", snapshot.capacityLevel)
        .putInt("autoSellLevel", snapshot.autoSellLevel)
        .putBoolean("soundEnabled", snapshot.soundEnabled)
        .putBoolean("vibrationEnabled", snapshot.vibrationEnabled)
        .putBoolean("darkTheme", snapshot.darkTheme)
        .putBoolean("languageEnglish", snapshot.languageEnglish)
        .apply()
}

private fun loadSnapshot(context: Context): GameSnapshot {
    val prefs = context.getSharedPreferences("sim_hunter", Context.MODE_PRIVATE)
    val raw = prefs.getString("collection", "[]") ?: "[]"
    val array = JSONArray(raw)
    val collection = buildList {
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            val countryKey = o.optString("country")
            val country = Countries.firstOrNull { it.key == countryKey } ?: continue
            add(
                PhoneNumber(
                    country = country,
                    localDigits = o.optString("digits"),
                    rarity = o.optString("rarity", "ОБЫЧНЫЙ"),
                    stars = o.optInt("stars", 1),
                    pattern = o.optString("pattern", "Обычный"),
                    estimatedValue = o.optLong("value", 300L)
                )
            )
        }
    }
    return GameSnapshot(
        coins = prefs.getLong("coins", 1250L),
        collection = collection,
        generatedCount = prefs.getInt("generatedCount", 0),
        soldCount = prefs.getInt("soldCount", 0),
        earnedCoins = prefs.getLong("earnedCoins", 0L),
        bestValue = prefs.getLong("bestValue", 0L),
        speedLevel = prefs.getInt("speedLevel", 0),
        luckLevel = prefs.getInt("luckLevel", 0),
        capacityLevel = prefs.getInt("capacityLevel", 0),
        autoSellLevel = prefs.getInt("autoSellLevel", 0),
        soundEnabled = prefs.getBoolean("soundEnabled", true),
        vibrationEnabled = prefs.getBoolean("vibrationEnabled", true),
        darkTheme = prefs.getBoolean("darkTheme", true),
        languageEnglish = prefs.getBoolean("languageEnglish", false)
    )
}

private fun playSound(context: Context, rare: Boolean) {
    try {
        val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
        tone.startTone(if (rare) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP, if (rare) 180 else 120)
        Handler(Looper.getMainLooper()).postDelayed({ tone.release() }, 240)
    } catch (_: Throwable) {
    }
}

private fun playTick(context: Context) {
    try {
        val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 30)
        tone.startTone(ToneGenerator.TONE_PROP_BEEP, 35)
        Handler(Looper.getMainLooper()).postDelayed({ tone.release() }, 60)
    } catch (_: Throwable) {
    }
}

private fun vibrate(context: Context, strong: Boolean) {
    try {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(VibratorManager::class.java).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        val duration = if (strong) 110L else 45L
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(duration, if (strong) 180 else 90))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(duration)
        }
    } catch (_: Throwable) {
    }
}
